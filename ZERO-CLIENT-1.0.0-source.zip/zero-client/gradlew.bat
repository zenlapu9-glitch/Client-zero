@echo off
setlocal
where gradle >nul 2>nul
if not errorlevel 1 goto USE_PATH
set VERSION=9.2.1
set CACHE=%USERPROFILE%\.gradle\zero-client-bootstrap\gradle-%VERSION%
if not exist "%CACHE%\bin\gradle.bat" (
  if not exist "%USERPROFILE%\.gradle\zero-client-bootstrap" mkdir "%USERPROFILE%\.gradle\zero-client-bootstrap"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip'; $z=Join-Path $env:USERPROFILE '.gradle\zero-client-bootstrap\gradle.zip'; Invoke-WebRequest $u -OutFile $z; Expand-Archive -Force $z (Join-Path $env:USERPROFILE '.gradle\zero-client-bootstrap'); Move-Item (Join-Path $env:USERPROFILE '.gradle\zero-client-bootstrap\gradle-%VERSION%') '%CACHE%'"
  if errorlevel 1 exit /b 1
)
call "%CACHE%\bin\gradle.bat" -p "%~dp0" %*
exit /b %errorlevel%

:USE_PATH
gradle -p "%~dp0" %*
exit /b %errorlevel%
