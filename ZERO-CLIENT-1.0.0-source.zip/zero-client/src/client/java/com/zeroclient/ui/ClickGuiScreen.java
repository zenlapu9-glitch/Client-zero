package com.zeroclient.ui;

import com.zeroclient.ZeroClient;
import com.zeroclient.core.ClientModule;
import com.zeroclient.core.ModuleCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.ArrayList;
import java.util.List;

public final class ClickGuiScreen extends Screen {
    private static final int PURPLE = 0xFF8B5CF6;
    private static final int PANEL = 0xF0141220;
    private static final int CARD = 0xFF211B30;
    private ModuleCategory selected = ModuleCategory.MOVEMENT;
    private final List<Row> rows = new ArrayList<>();

    public ClickGuiScreen() { super(Component.literal("ZERO CLIENT")); }

    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        renderBackground(g, mouseX, mouseY, delta);
        int left = Math.max(12, (width - 520) / 2), top = Math.max(12, (height - 310) / 2);
        g.fill(left, top, left + 520, top + 310, PANEL);
        g.fill(left, top, left + 520, top + 3, PURPLE);
        g.drawString(font, "ZERO CLIENT", left + 18, top + 16, 0xFFFFFFFF, false);
        g.drawString(font, "1.0.0  •  FABRIC 1.21.11", left + 18, top + 31, 0xFFB9A7D9, false);
        int sy = top + 58;
        for (ModuleCategory category : ModuleCategory.values()) {
            int color = category == selected ? PURPLE : 0xFF30283D;
            g.fill(left + 14, sy, left + 132, sy + 25, color);
            g.drawString(font, title(category), left + 23, sy + 8, 0xFFFFFFFF, false);
            sy += 30;
        }
        g.drawString(font, title(selected) + " MODULES", left + 151, top + 62, 0xFFFFFFFF, false);
        rows.clear();
        int y = top + 84;
        for (ClientModule module : ZeroClient.MODULES.in(selected)) {
            if (y > top + 270) break;
            g.fill(left + 148, y, left + 505, y + 48, CARD);
            g.drawString(font, module.name(), left + 160, y + 8, 0xFFFFFFFF, false);
            g.drawString(font, module.description(), left + 160, y + 23, 0xFFB8AEC7, false);
            int toggle = module.enabled() ? 0xFF8B5CF6 : 0xFF51485E;
            g.fill(left + 455, y + 14, left + 490, y + 32, toggle);
            g.drawString(font, module.enabled() ? "ON" : "OFF", left + 461, y + 19, 0xFFFFFFFF, false);
            rows.add(new Row(module, left + 148, y, left + 505, y + 48));
            y += 55;
        }
        g.drawString(font, "Right Shift: open/close  •  Click a module to toggle", left + 150, top + 286, 0xFF9B8EAA, false);
        super.render(g, mouseX, mouseY, delta);
    }

    @Override public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        int left = Math.max(12, (width - 520) / 2), top = Math.max(12, (height - 310) / 2);
        int sy = top + 58;
        for (ModuleCategory category : ModuleCategory.values()) {
            if (mouseX >= left + 14 && mouseX <= left + 132 && mouseY >= sy && mouseY <= sy + 25) { selected = category; return true; }
            sy += 30;
        }
        for (Row row : rows) if (mouseX >= row.x1 && mouseX <= row.x2 && mouseY >= row.y1 && mouseY <= row.y2) {
            row.module.toggle(Minecraft.getInstance());
            ZeroClient.notify(row.module.name() + (row.module.enabled() ? " enabled" : " disabled"));
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private String title(ModuleCategory category) {
        String s = category.name().toLowerCase();
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }
    @Override public boolean isPauseScreen() { return false; }
    private record Row(ClientModule module, int x1, int y1, int x2, int y2) { }
}
