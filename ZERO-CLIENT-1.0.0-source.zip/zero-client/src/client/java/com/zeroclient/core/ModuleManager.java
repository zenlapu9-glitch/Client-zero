package com.zeroclient.core;

import com.zeroclient.ZeroClient;
import com.zeroclient.module.AutoSprintModule;
import com.zeroclient.module.FullbrightModule;
import com.zeroclient.module.ZoomModule;
import net.minecraft.client.Minecraft;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleManager {
    private final List<ClientModule> modules = new ArrayList<>();
    public void add(ClientModule module) { modules.add(module); }
    public List<ClientModule> all() { return Collections.unmodifiableList(modules); }
    public List<ClientModule> in(ModuleCategory category) { return modules.stream().filter(m -> m.category() == category).toList(); }
    public ClientModule find(String name) { return modules.stream().filter(m -> m.name().equalsIgnoreCase(name)).findFirst().orElse(null); }
    public void registerDefaults() {
        add(new AutoSprintModule());
        add(new FullbrightModule());
        add(new ZoomModule());
    }
    public void tick(Minecraft client) {
        for (ClientModule module : modules) if (module.enabled()) {
            try { module.tick(client); } catch (RuntimeException ex) {
                module.setEnabled(false, client);
                ZeroClient.notify(module.name() + " disabled after an error.");
            }
        }
    }
}
