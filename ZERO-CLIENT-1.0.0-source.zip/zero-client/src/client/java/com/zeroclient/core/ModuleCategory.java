package com.zeroclient.core;

public enum ModuleCategory { COMBAT, MOVEMENT, PLAYER, VISUAL, WORLD, HUD, MISC, SETTINGS }
