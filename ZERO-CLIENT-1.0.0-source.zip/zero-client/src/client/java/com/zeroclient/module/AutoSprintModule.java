package com.zeroclient.module;

import com.zeroclient.core.ClientModule;
import com.zeroclient.core.ModuleCategory;
import net.minecraft.client.Minecraft;

public final class AutoSprintModule extends ClientModule {
    public AutoSprintModule() { super("Auto Sprint", "Automatically sprint while moving forward.", ModuleCategory.MOVEMENT); }
    @Override public void tick(Minecraft client) {
        if (client.player == null || client.options == null) return;
        boolean movingForward = client.options.keyUp.isDown();
        if (movingForward && !client.player.isPassenger()) client.player.setSprinting(true);
    }
}
