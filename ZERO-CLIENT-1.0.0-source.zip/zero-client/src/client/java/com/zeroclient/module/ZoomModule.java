package com.zeroclient.module;

import com.zeroclient.core.ClientModule;
import com.zeroclient.core.ModuleCategory;
import net.minecraft.client.Minecraft;

public final class ZoomModule extends ClientModule {
    private int previousFov;
    public ZoomModule() { super("Zoom", "Temporarily narrows the field of view while enabled.", ModuleCategory.VISUAL); }
    @Override protected void onEnable(Minecraft client) {
        if (client.options != null) { previousFov = client.options.fov().get(); client.options.fov().set(30); }
    }
    @Override protected void onDisable(Minecraft client) {
        if (client.options != null) client.options.fov().set(previousFov);
    }
}
