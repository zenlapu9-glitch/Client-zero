package com.zeroclient.module;

import com.zeroclient.core.ClientModule;
import com.zeroclient.core.ModuleCategory;
import net.minecraft.client.Minecraft;

public final class FullbrightModule extends ClientModule {
    private double previousGamma;
    public FullbrightModule() { super("Fullbright", "Raises client gamma while enabled; restores the prior value when disabled.", ModuleCategory.VISUAL); }
    @Override protected void onEnable(Minecraft client) {
        if (client.options != null) { previousGamma = client.options.gamma().get(); client.options.gamma().set(16.0); }
    }
    @Override protected void onDisable(Minecraft client) {
        if (client.options != null) client.options.gamma().set(previousGamma);
    }
}
