package com.zeroclient.config;

import com.zeroclient.core.ClientModule;
import com.zeroclient.core.ModuleManager;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Locale;
import java.util.Properties;
import java.util.regex.Pattern;

/** Persists enabled module states in named, user-editable profiles. */
public final class ConfigManager {
    private static final Pattern PROFILE_NAME = Pattern.compile("[A-Za-z0-9_-]{1,32}");
    private final Path profileDirectory = FabricLoader.getInstance().getConfigDir()
            .resolve("zero-client").resolve("profiles");
    private String activeProfile = "default";
    private boolean loading;

    public String activeProfile() {
        return activeProfile;
    }

    public void load(ModuleManager modules, Minecraft client) {
        loading = true;
        try {
            Path file = profilePath(activeProfile);
            if (!Files.isRegularFile(file)) return;

            Properties properties = new Properties();
            try (InputStream input = Files.newInputStream(file)) {
                properties.load(input);
            }

            for (ClientModule module : modules.all()) {
                String key = moduleKey(module);
                boolean enabled = Boolean.parseBoolean(properties.getProperty(key, "false"));
                module.setEnabled(enabled, client);
            }
        } catch (IOException exception) {
            System.err.println("[ZERO CLIENT] Could not load profile: " + exception.getMessage());
        } finally {
            loading = false;
        }
    }

    public void save(ModuleManager modules) {
        if (loading) return;
        try {
            Files.createDirectories(profileDirectory);
            Properties properties = new Properties();
            properties.setProperty("client", "ZERO CLIENT");
            properties.setProperty("version", "1.0.0");
            properties.setProperty("profile", activeProfile);
            for (ClientModule module : modules.all()) {
                properties.setProperty(moduleKey(module), Boolean.toString(module.enabled()));
            }

            Path destination = profilePath(activeProfile);
            Path temporary = destination.resolveSibling(destination.getFileName() + ".tmp");
            try (OutputStream output = Files.newOutputStream(temporary)) {
                properties.store(output, "ZERO CLIENT module configuration");
            }
            try {
                Files.move(temporary, destination, StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ignored) {
                Files.move(temporary, destination, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException exception) {
            System.err.println("[ZERO CLIENT] Could not save profile: " + exception.getMessage());
        }
    }

    public boolean switchProfile(String name, ModuleManager modules, Minecraft client) {
        if (name == null || !PROFILE_NAME.matcher(name).matches()) return false;
        save(modules);
        activeProfile = name.toLowerCase(Locale.ROOT);
        load(modules, client);
        save(modules);
        return true;
    }

    private Path profilePath(String name) {
        return profileDirectory.resolve(name + ".properties");
    }

    private String moduleKey(ClientModule module) {
        String normalized = module.name().toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "_");
        return "module." + normalized + ".enabled";
    }
}
