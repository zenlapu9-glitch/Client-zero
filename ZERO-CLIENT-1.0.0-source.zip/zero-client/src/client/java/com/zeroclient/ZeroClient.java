package com.zeroclient;

import com.zeroclient.core.ModuleManager;
import com.zeroclient.config.ConfigManager;
import com.zeroclient.ui.ClickGuiScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public final class ZeroClient implements ClientModInitializer {
    public static final String MOD_ID = "zeroclient";
    public static final ModuleManager MODULES = new ModuleManager();
    public static final ConfigManager CONFIG = new ConfigManager();
    private static KeyMapping clickGuiKey;

    @Override
    public void onInitializeClient() {
        MODULES.registerDefaults();
        CONFIG.load(MODULES, Minecraft.getInstance());
        clickGuiKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.zeroclient.clickgui", GLFW.GLFW_KEY_RIGHT_SHIFT, KeyMapping.Category.MISC));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (clickGuiKey.consumeClick()) {
                if (client.screen == null) client.setScreen(new ClickGuiScreen());
            }
            MODULES.tick(client);
        });
    }

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    public static void notify(String message) {
        Minecraft client = Minecraft.getInstance();
        if (client.player != null) client.player.displayClientMessage(Component.literal("§5[ZERO] §f" + message), true);
    }
}
