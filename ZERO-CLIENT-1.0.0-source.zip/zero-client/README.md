# ZERO CLIENT 1.0.0

A client-side Fabric mod project for Minecraft Java Edition **1.21.11**, Java 21. Purple/black custom ClickGUI opens with **Right Shift**.

## Implemented in this starter build

- Custom category-based ClickGUI with module toggles and enabled-state indicators.
- Module manager with lifecycle callbacks and runtime error isolation.
- Persistent enabled-state profiles saved under `.minecraft/config/zero-client/profiles/` (the `default` profile is loaded on startup).
- Auto Sprint (sprint while holding forward).
- Fullbright (raises gamma and restores the previous value when disabled).
- Zoom (sets a narrower FOV and restores the previous value when disabled).
- Pinned Gradle/Fabric/Minecraft dependency configuration and production remap verification.
- GitHub Actions build that uploads the remapped production JAR.

## Important scope note

This repository is a **working foundation**, not the full feature list from the original master prompt. The requested combat automation, movement exploits, ESP/X-ray, scaffold, inventory automation, configurable HUD suite, profile-selection UI, and advanced GUI settings are not implemented here. Profiles can be changed through the `ConfigManager` API, but a profile editor is not yet exposed in the GUI. These are deliberately not represented as working modules. Do not use this project as evidence that those features or multiplayer compatibility have been tested.

## Requirements

- JDK 21
- Internet access on first build (Gradle, Minecraft, Fabric Loader, mappings, and Fabric API must be downloaded)

## Build

Linux/macOS:

```sh
chmod +x ./gradlew
./gradlew clean build
```

Windows:

```bat
gradlew.bat clean build
```

The remapped production JAR is expected at `build/libs/zero-client-1.0.0.jar`. The build's `verifyProductionJar` task checks that the archive contains `fabric.mod.json` and the client entrypoint class. The supplied `gradlew` is a lightweight bootstrap script, not the standard Gradle wrapper JAR; first use requires network access to download Gradle 9.2.1 unless a compatible Gradle installation is already on `PATH`.

## Install

Copy the production JAR into the `mods` folder for a Minecraft **1.21.11 Fabric** instance with Fabric API installed. Back up worlds before testing. Android/Zalith compatibility is unverified; a successful desktop build does not establish Android runtime compatibility.

## GitHub Actions

Push this project to a GitHub repository. The workflow at `.github/workflows/build.yml` runs the build on GitHub-hosted runners and uploads `zero-client-1.0.0` as a downloadable workflow artifact. This project has not been pushed to a repository from this environment.

## Dependency baseline

- Minecraft: `1.21.11`
- Java: `21`
- Fabric Loader: `0.18.1`
- Fabric API: `0.141.1+1.21.11`
- Fabric Loom remap plugin: `1.14.10`
- Gradle: `9.2.1`

Check current upstream release notes before updating pinned versions.
